//
//  xcodeRefreshApp.swift
//  xcodeRefresh
//
//  Created by Kat Barber on 4/21/24.
//

import SwiftUI

@main
struct xcodeRefreshApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
